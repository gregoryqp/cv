function handleStorageChange(event) {
  if (event.key === "imie" || event.key === "nazwisko") {
    wyslijWniosek();
  }
}

// Rejestrowanie obsługi zdarzenia storage
window.addEventListener("storage", handleStorageChange);

function wyslijWniosek() {
  let imieZLocalStorage = localStorage.getItem("imie");
  let nazwiskoZLocalStorage = localStorage.getItem("nazwisko");

  let testowyodczyt = document.querySelector(".wniosek2");

  testowyodczyt.innerHTML = imieZLocalStorage + " " + nazwiskoZLocalStorage;
  let test = testowyodczyt.innerHTML;

  console.log(test);
}

function rozwinHover() {
  let el = document.querySelector(".wniosek");
  el.classList.toggle("active");
}

function stopPropagation(event) {
  event.stopPropagation();
}
