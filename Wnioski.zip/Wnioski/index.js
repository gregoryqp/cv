let imie = document.querySelector("#imie");
let nazwisko = document.querySelector("#nazwisko");
let urlopOd = document.querySelector("#urlopOd");
let urlopDo = document.querySelector("#urlopDo");
let lacznaLiczbaDni = document.querySelector("#lacznie");
let test = document.querySelector(".test");
let rodzajWniosku = document.querySelector(".rodzajWniosku");
let rodzajWnioskuOPomoc = document.querySelector(".sytuacjaMaterialna");
let sytucja = document.querySelector(".sytuacja");
let button = document.querySelector(".wartosc");
let result = document.querySelector(".podsumowanie");

// let trescPDF;
let aktualny = "";
let sytyacjaMaterialnaRodziny = "";

// function generujPDF(arg) {
//   let pdf = new jsPDF();
//   pdf.formHTML(arg, 10, 10);
//   pdf.save("dokument.pdf");
// }

const pobierzInputa = () => {
  let pobraneImie = imie.querySelector("input[name='imie']");
  let pobraneNazwisko = nazwisko.querySelector("input[name='nazwisko']");
  let pobranaDataOd = urlopOd.querySelector("input[name='okresOd']");
  let pobranaDataDo = urlopDo.querySelector("input[name='okresDo']");
  let pobranaLacznaIloscDni = lacznaLiczbaDni.querySelector(
    "input[name='okresLacznie']"
  );

  let wprowadzoneImie = pobraneImie.value;
  let wprowadzoneNazwisko = pobraneNazwisko.value;
  let wprowadzonaDataOd = pobranaDataOd.value;
  let wprowadzonaDataDo = pobranaDataDo.value;
  let wprowadzonaLacznaIloscDni = pobranaLacznaIloscDni.value;
  let imieINazwisko = document.querySelector(".wniosek2");
  let daneUrlopu = document.querySelector(".wniosekOsobowy");

  daneUrlopu.innerText = wprowadzoneImie;
};

const pobierzInputaPomoc = () => {
  let pobraneImie = imie.querySelector("input[name='imie']");
  let pobraneNazwisko = nazwisko.querySelector("input[name='nazwisko']");

  let imieNaWnioskuOPomoc = pobraneImie.value;
  let nazwiskoNaWnioskuOPomoc = pobraneNazwisko.value;

  console.log(
    "Wniosek o: " +
      aktualny +
      "\nDla: " +
      imieNaWnioskuOPomoc +
      " " +
      nazwiskoNaWnioskuOPomoc +
      "\nSytuacja materialna: " +
      sytyacjaMaterialnaRodziny
  );
};

const sprawdzenieRodzajuWniosku = () => {
  if (aktualny === "Pomoc wiosenna" || aktualny === "Pomoc świąteczna") {
    urlopOd.classList.add("hideElement");
    urlopDo.classList.add("hideElement");
    lacznaLiczbaDni.classList.add("hideElement");
    sytucja.classList.remove("hideElement");
    button.addEventListener("click", pobierzInputaPomoc);
  } else {
    urlopOd.classList.remove("hideElement");
    urlopDo.classList.remove("hideElement");
    lacznaLiczbaDni.classList.remove("hideElement");
    sytucja.classList.add("hideElement");
    button.addEventListener("click", pobierzInputa);
  }
};

rodzajWnioskuOPomoc.addEventListener("change", (event) => {
  sytyacjaMaterialnaRodziny = `${event.target.value}`;
  sprawdzenieRodzajuWniosku();
});

rodzajWniosku.addEventListener("change", (event) => {
  aktualny = `${event.target.value}`;
  sprawdzenieRodzajuWniosku();
});

function rozwinHover() {
  let el = document.querySelector(".wniosek");
  el.classList.toggle("active");
}

function stopPropagation(event) {
  event.stopPropagation();
}
