function handleStorageChange(event) {
  if (event.key === "imie" || event.key === "nazwisko") {
    utworzNowyWniosek();
  } else {
    console.log(event.key);
  }
}

window.addEventListener("storage", handleStorageChange);

function utworzNowyWniosek() {
  let imieZLocalStorage = localStorage.getItem("imie");
  let nazwiskoZLocalStorage = localStorage.getItem("nazwisko");

  let listaWnioskow = document.querySelector(".listaWnioskow");

  let nowyWnisoekNaLiscie = document.createElement("div");

  nowyWnisoekNaLiscie.textContent = imieZLocalStorage + nazwiskoZLocalStorage;

  listaWnioskow.appendChild(nowyWnisoekNaLiscie);

  nowyWnisoekNaLiscie.addEventListener("click", rozwinHover);
}

function rozwinHover() {
  let el = document.querySelector(".wniosek");
  el.classList.toggle("active");
}

function stopPropagation(event) {
  event.stopPropagation();
}
