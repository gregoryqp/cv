let nameFromInput = document.querySelector("#name");
let surnameFromInput = document.querySelector("#surname");
let sentDataButton = document.querySelector("#sentData");
let getDataButton = document.querySelector("#getDataFromLocalStorageButton");
let applicationsList = document.querySelector("#listaWnioskow");
let employee = {};

function createObject() {
  employee.name = nameFromInput.value;
  employee.surname = surnameFromInput.value;
}

function setItemInDataStorage() {
  localStorage.setItem("employeeData", JSON.stringify(employee));
}

function getItemFromDataStorage() {
  let retrievedData = JSON.parse(localStorage.getItem("employeeData"));
  applicationsList.innerText = retrievedData.name + " " + retrievedData.surname;
}

function newApplication() {
  createObject();
  setItemInDataStorage();
}
window.addEventListener("storage", () => {
  if (localStorage !== null) {
    getItemFromDataStorage();
  }
});
window.addEventListener("load", () => {
  if (localStorage === null) {
    return;
  } else {
    getItemFromDataStorage();
  }
});

if (sentDataButton) {
  sentDataButton.addEventListener("click", newApplication);
} else {
  getDataButton.addEventListener("click", getItemFromDataStorage);
}
